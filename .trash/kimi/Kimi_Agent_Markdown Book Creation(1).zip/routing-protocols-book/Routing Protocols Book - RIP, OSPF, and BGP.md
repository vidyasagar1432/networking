# Routing Protocols: RIP, OSPF, and BGP

**A Complete Study Book Based on the CSA510 Lecture Series**

---

## About This Book

This book is a faithful adaptation of the CSA510 lecture slides *Routing Protocols (RIP, OSPF, and BGP)* into a structured, book-style format. The slide bullet points have been expanded into flowing explanations, the worked examples have been preserved and typeset, and every diagram from the original deck has been reproduced as a figure. Each chapter closes with a summary and review questions; answers, quick-reference tables, and a glossary are collected in the appendices.

**How to read this book.** Read Chapters 1 and 2 first — they establish the vocabulary (metrics, autonomous systems, interior versus exterior routing) that the three protocol chapters rely on. Chapters 3 (RIP), 4 (OSPF), and 5 (BGP) are then independent of one another, although reading them in order makes the comparison in Chapter 6 more meaningful.

---

## Table of Contents

- **Chapter 1 — Introduction to Routing**
  - 1.1 The Routing Problem
  - 1.2 Metrics: The Cost of a Route
  - 1.3 Static and Dynamic Routing Tables
- **Chapter 2 — Interior and Exterior Routing**
  - 2.1 Autonomous Systems
  - 2.2 Interior Routing
  - 2.3 Exterior Routing
- **Chapter 3 — RIP: Routing Information Protocol**
  - 3.1 Overview
  - 3.2 Distance Vector Routing
  - 3.3 Updating the Routing Table
  - 3.4 The RIP Message Format
  - 3.5 Requests and Responses
  - 3.6 Timers in RIP
  - 3.7 Problems in RIP
  - 3.8 Remedies for Instability
  - 3.9 RIP Version 2
  - 3.10 Encapsulation
  - Chapter Summary & Review Questions
- **Chapter 4 — OSPF: Open Shortest Path First**
  - 4.1 Overview
  - 4.2 Areas
  - 4.3 Metrics
  - 4.4 Link State Routing
  - 4.5 Types of Links
  - 4.6 Link State Advertisements
  - 4.7 The Link State Database and the Dijkstra Algorithm
  - 4.8 The OSPF Routing Table
  - 4.9 OSPF Packets
  - 4.10 The LSA Formats
  - 4.11 Encapsulation
  - Chapter Summary & Review Questions
- **Chapter 5 — BGP: Border Gateway Protocol**
  - 5.1 Overview
  - 5.2 Why Neither Distance Vector nor Link State?
  - 5.3 Path Vector Routing
  - 5.4 Loop Prevention and Policy Routing
  - 5.5 Path Attributes
  - 5.6 BGP Messages
  - 5.7 Encapsulation
  - Chapter Summary & Review Questions
- **Chapter 6 — Comparing RIP, OSPF, and BGP**
- **Appendix A — Quick-Reference Tables**
- **Appendix B — Glossary**
- **Appendix C — Answers to Review Questions**

---

# Chapter 1 — Introduction to Routing

## 1.1 The Routing Problem

An **internet** is a combination of networks connected by routers. When a host on one network sends a packet to a host on another network, the packet must travel through one or more routers before it reaches its destination. This raises two fundamental questions:

1. How should a packet be passed from its source to its destination?
2. Of all the available pathways, which one is the *optimum* pathway?

The answer to the second question depends on the **metric**.

## 1.2 Metrics: The Cost of a Route

A **metric** is a cost assigned for passing through a network. A router should choose the route with the smallest metric. However, the metric assigned to each network depends on the type of protocol being used:

- **RIP (Routing Information Protocol)** treats each network as an equal. The cost of passing through each network is the same: **one hop count**.
- **OSPF (Open Shortest Path First)** allows the administrator to assign a cost for passing through a network based on the type of service required — for example, maximum throughput or minimum delay.
- **BGP (Border Gateway Protocol)** uses a different criterion altogether: the **policy**, which can be set by the administrator.

## 1.3 Static and Dynamic Routing Tables

A routing table can be **static** or **dynamic**. A static table is configured by hand and does not change as the network changes; a dynamic table updates itself automatically as routers learn about the network. An internet needs **dynamic routing tables**, and dynamic routing tables are achieved by the **routing protocols** — the subject of this book.

### Chapter 1 Summary

- An internet is a combination of networks connected by routers.
- A metric is the cost of passing through a network; routers prefer the smallest metric.
- RIP uses hop count, OSPF uses an administrator-assigned cost based on type of service, and BGP uses policy.
- Internets need dynamic routing tables, which are maintained by routing protocols.

### Review Questions

1. Define the term *metric*.
2. How does the metric used by RIP differ from the metric used by OSPF?
3. What criterion does BGP use to select a route?
4. Why does an internet need dynamic routing tables rather than static ones?

---

# Chapter 2 — Interior and Exterior Routing

## 2.1 Autonomous Systems

An internet can be so large that one routing protocol cannot handle the task of updating the routing tables of all routers. For this reason, an internet is divided into **autonomous systems (ASs)**. An autonomous system is a group of networks and routers under the authority of a single administration.

![Popular routing protocols](images/fig-13-01-popular-routing-protocols.png)

*Figure 2.1 — Popular routing protocols: interior protocols operate inside an AS; the exterior protocol operates between ASs.*

## 2.2 Interior Routing

**Interior routing** is routing *inside* an autonomous system. Each AS can choose its own interior routing protocol. The two interior routing protocols covered in this book are:

- **RIP** — Routing Information Protocol (Chapter 3)
- **OSPF** — Open Shortest Path First (Chapter 4)

## 2.3 Exterior Routing

**Exterior routing** is routing *between* autonomous systems. Usually only one exterior routing protocol is used for exterior routing:

- **BGP** — Border Gateway Protocol (Chapter 5)

In practice, the boundary routers of an autonomous system run **both** an interior and an exterior routing protocol. In the figure below, routers R1, R2, R3, and R4 each use an interior routing protocol inside their own AS (solid thin lines) and an exterior routing protocol between autonomous systems (broken thick lines).

![Autonomous systems](images/fig-13-02-autonomous-systems.png)

*Figure 2.2 — Autonomous systems. Boundary routers run an interior protocol within the AS and an exterior protocol between ASs.*

### Chapter 2 Summary

- An internet is divided into autonomous systems: groups of networks and routers under a single administration.
- Interior routing takes place inside an AS (RIP, OSPF); each AS chooses its own interior protocol.
- Exterior routing takes place between autonomous systems (BGP); normally a single exterior protocol is used.
- Boundary routers run both kinds of protocol.

### Review Questions

1. What is an autonomous system?
2. Why is an internet divided into autonomous systems?
3. Classify RIP, OSPF, and BGP as interior or exterior routing protocols.
4. Which routers in an AS typically run both an interior and an exterior routing protocol?

---

# Chapter 3 — RIP: Routing Information Protocol

## 3.1 Overview

The **Routing Information Protocol (RIP)** is an interior routing protocol based on **distance vector routing**. It uses the **Bellman–Ford algorithm** for calculating the routing tables.

## 3.2 Distance Vector Routing

In distance vector routing, each router periodically shares its knowledge about the entire internet with its neighbors. The method rests on three keys:

1. **Sharing knowledge about the entire AS.** At the start, a router's knowledge may be sparse. But how much it knows is unimportant — it sends whatever it has.
2. **Sharing only with neighbors.** A router sends its knowledge only to its neighbors.
3. **Sharing at regular intervals.** A router sends its knowledge at fixed periodic intervals (every 30 seconds).

## 3.3 Updating the Routing Table

The routing table is updated on receipt of a RIP response message. When a router receives such a message, it first **adds one hop** to the hop count for each advertised destination, and then repeats the following steps for each advertised destination:

```
On receipt of a response RIP message:
    Add one hop to the hop count for each advertised destination.
    Repeat the following steps for each advertised destination:
        If (destination is not in the routing table)
            Add the advertised information to the table.
        Else
            If (next-hop field is the same)
                Replace entry in the table with the advertised one.
            Else
                If (advertised hop count is smaller than the one in the table)
                    Replace entry in the routing table.
    Return.
```

The figure below shows this algorithm in action: a router receives an advertisement for several networks and merges it with its current table — adding new destinations, refreshing entries that point to the same next hop, and replacing entries only when the advertised hop count is smaller.

![Example of updating a routing table](images/fig-rip-table-update-example.png)

*Figure 3.1 — Example of updating a routing table on receipt of a RIP response.*

### Initializing the Routing Table

When a router is added to a network, it initializes a routing table for itself using its **configuration file**. The table contains only the **directly attached networks** and the hop count, which is set to **1**.

### Updating After Initialization

After initialization, each routing table is updated upon receipt of RIP messages using the updating algorithm shown above. The next two figures show the initial and final routing tables of a small autonomous system: initially each router knows only its directly connected networks (hop count 1, no next hop); after the exchange of RIP messages, every router knows how to reach every network in the AS.

![Initial routing tables in a small autonomous system](images/fig-initial-routing-tables.png)

*Figure 3.2 — Initial routing tables: only directly attached networks, hop count 1.*

![Final routing tables](images/fig-final-routing-tables.png)

*Figure 3.3 — Final routing tables after RIP updates have propagated through the AS.*

## 3.4 The RIP Message Format

A RIP message consists of a header followed by one or more entries. The fields are:

| Field | Size | Description |
|---|---|---|
| **Command** | 8 bits | The type of message: **request (1)** or **response (2)**. |
| **Version** | 8 bits | Defines the RIP version. |
| **Family** | 16 bits | Defines the family of the protocol used; for TCP/IP the value is **2**. |
| **Address** | 14 bytes | Defines the address of the destination network. Fourteen bytes are reserved so that the field is applicable to any protocol; however, IP currently uses only 4 bytes, and the rest are all 0s. |
| **Distance** | 32 bits | The hop count from the advertising router to the destination network. |

![RIP message format](images/fig-13-06-rip-message-format.png)

*Figure 3.4 — The RIP message format. The address, all-0s padding, and distance fields are repeated for each advertised destination.*

## 3.5 Requests and Responses

RIP uses two types of messages: **request** and **response**.

### Request

A request is sent by a router that has just come up, or by a router that has some timed-out entries. A request can ask about **specific entries** or **all entries**.

![Request messages](images/fig-13-07-request-messages.png)

*Figure 3.5 — Request messages: a request for all entries (left) and for specific entries (right).*

### Response

A response can be **solicited** or **unsolicited**:

- A **solicited response** is sent only in answer to a request. It contains information about the destinations specified in the corresponding request.
- An **unsolicited response** is sent periodically, **every 30 seconds**. It contains information about the entire routing table and is also called the **update packet**.

> **Example 3.1** — What is the periodic response sent by router R1 in the figure below? Assume R1 knows about the whole autonomous system.

![Example 1 topology](images/fig-13-08-example-1.png)

*Figure 3.6 — Topology for Example 3.1.*

> **Solution.** R1 can advertise three networks: 144.2.7.0, 144.2.9.0, and 144.2.12.0. The periodic response (update packet) is shown below.

![Solution to Example 1](images/fig-13-09-solution-example-1.png)

*Figure 3.7 — The update packet sent by R1.*

## 3.6 Timers in RIP

RIP uses **three timers** to manage its operation:

![RIP timers](images/fig-13-10-rip-timers.png)

*Figure 3.8 — The three RIP timers.*

### Periodic Timer

The **periodic timer** controls the advertising of regular update messages. Although the protocol specifies **30 seconds**, the working model uses a random number between **25 and 35 seconds**. The randomization prevents routers on the same network from updating simultaneously.

### Expiration Timer

The **expiration timer** governs the validity of a route. It is set to **180 seconds** for a route whenever the router receives update information for that route. If a new update for the route is received, the timer is reset — in normal operation this happens every 30 seconds. If the timer ever goes off, the route is considered **expired**: the hop count of the route is set to **16**, which means the destination is **unreachable**.

### Garbage Collection Timer

When a route becomes invalid, the router does **not** immediately purge that route from its table. Instead, it continues to advertise the route with a metric value of **16**. A **garbage collection timer** is set to **120 seconds** for that route. When the count reaches zero, the route is purged from the table. This delay allows neighbors to become aware of the invalidity of a route prior to purging.

> **Example 3.2** — A routing table has 20 entries. It does not receive information about five routes for 200 seconds. How many timers are running at this time?
>
> **Solution.** The timers running are:
>
> | Timer | Count |
> |---|---|
> | Periodic timer | 1 |
> | Expiration timer | 20 − 5 = 15 |
> | Garbage collection timer | 5 |

## 3.7 Problems in RIP

RIP suffers from two significant problems: **slow convergence** and **instability**.

### Slow Convergence

A change somewhere in the internet propagates very slowly through the rest of the internet. For example, suppose there is a change in Net1 in the figure below. Router R1 updates itself immediately, but on average it takes **15 seconds** (half of the 30-second update period) for the news to reach R2, another 15 seconds to reach R3, and so on. Reaching Rn therefore takes an average of **15 × n seconds**.

![Slow convergence](images/fig-13-11-slow-convergence.png)

*Figure 3.9 — Slow convergence: news of a change advances roughly one router per update interval.*

**Solution: limit the hop count to 15.** Limiting the hop count prevents a data packet from wandering around forever. As a consequence, an autonomous system using RIP is limited to a diameter of **15 hops**. The number **16 is considered infinity** and designates an unreachable network.

![Hop count limit](images/fig-13-12-hop-count.png)

*Figure 3.10 — The total hop count in a RIP network must be less than 16.*

### Instability

An internet running RIP can become **unstable**: a packet could go from one router to another in a loop. The figure below shows the classic scenario. Net1 fails; router A marks it unreachable (metric 16), but before A can advertise this, B advertises to A that it can reach Net1 in 2 hops. A concludes that Net1 is reachable through B in 3 hops — and the two routers proceed to feed each other ever-increasing metrics, a problem known as **counting to infinity**.

![Instability in RIP](images/fig-instability.png)

*Figure 3.11 — Instability: after Net1 fails, routers A and B loop advertisements with ever-increasing hop counts.*

## 3.8 Remedies for Instability

Three remedies are used to fight instability in RIP:

### Triggered Update

If there is no change, updates are sent at the usual 30-second intervals. If there **is** a change, the router sends out its new table **immediately**, without waiting for the periodic timer to expire.

### Split Horizons

In split horizon, a router must distinguish between its different interfaces. If a router received route update information from an interface, this same updated information **must not be sent back** through that interface. For example, in the figure below, router B receives information about Net1 and Net2 through its left interface; this information is updated and passed on through the right interface, but **not** back through the left one.

![Split horizon](images/fig-13-14-split-horizon.png)

*Figure 3.12 — Split horizon: information learned on an interface is never advertised back out of it.*

### Poison Reverse

**Poison reverse** is a variation of split horizons. Information received is used to update the routing table and is then passed out to **all** interfaces. However, a table entry that has come through one interface is set to a **metric of 16** as it goes out through the same interface. For example, router B has received information about Net1 and Net2 through its left interface, so it sends information about Net1 and Net2 out of that interface with a metric of **16** — explicitly poisoning the route so no neighbor will try to reach those networks through B.

![Poison reverse](images/fig-13-15-poison-reverse.png)

*Figure 3.13 — Poison reverse: routes learned on an interface are advertised back out of it with metric 16.*

## 3.9 RIP Version 2

RIP version 2 does **not** augment the length of the message of each entry. It only replaces those fields in version 1 that were filled with 0s with some new fields:

- **Routing tag** — carries information such as the autonomous system number. It enables RIP to receive information from an exterior routing protocol.
- **Subnet mask** — carries the subnet mask (or prefix). This means **RIP version 2 supports classless addressing and CIDR**.
- **Next-hop address** — shows the address of the next hop.

![RIP version 2 format](images/fig-13-16-rip-v2-format.png)

*Figure 3.14 — The RIP version 2 message format.*

### Authentication

Authentication is added to protect the message against unauthorized advertisement. The **first entry** of the message is set aside for authentication information, and its **family field is set to FFFF (hexadecimal)** to mark it as an authentication entry rather than a route.

![Authentication entry](images/fig-13-17-authentication.png)

*Figure 3.15 — The authentication entry in RIP version 2.*

### Multicasting

Version 1 of RIP uses **broadcasting** to send RIP messages to every neighbor — all the routers **and the hosts** receive the packets. RIP version 2 instead uses the multicast address **224.0.0.9** to multicast RIP messages only to RIP routers in the network.

## 3.10 Encapsulation

RIP messages are encapsulated in **UDP user datagrams**. The well-known port assigned to RIP in UDP is **port 520**.

> **Note:** RIP uses the services of UDP on well-known port 520.

### Chapter 3 Summary

- RIP is an interior routing protocol based on distance vector routing and the Bellman–Ford algorithm.
- Each router shares everything it knows about the AS, but only with its neighbors, and only at regular intervals (every 30 s).
- The update algorithm adds one hop to each advertised destination, then inserts new destinations, refreshes same-next-hop entries, and replaces entries when the advertised route is shorter.
- A RIP message has command, version, family, address, and distance fields; requests can be general or specific; responses can be solicited or unsolicited (periodic update packets).
- Three timers govern RIP: periodic (25–35 s), expiration (180 s), and garbage collection (120 s).
- RIP's two major problems are slow convergence (remedied by a 15-hop limit; 16 means infinity/unreachable) and instability (remedied by triggered updates, split horizons, and poison reverse).
- RIP version 2 adds a routing tag, a subnet mask (CIDR support), a next-hop address, authentication, and multicasting to 224.0.0.9.
- RIP messages are encapsulated in UDP on port 520.

### Review Questions

1. Name the three keys of distance vector routing.
2. In the RIP updating algorithm, what happens when an advertised destination is already in the routing table with the same next-hop field?
3. A router has just been added to a network. What does its initial routing table contain?
4. State the purpose and the value of each of the three RIP timers.
5. A routing table has 30 entries. No information has been received about 8 routes for 200 seconds. How many expiration timers and garbage collection timers are running?
6. Why does RIP limit the hop count to 15? What does a hop count of 16 mean?
7. Explain the difference between split horizons and poison reverse.
8. Which new fields does RIP version 2 add, and what does each one do?
9. Which multicast address does RIPv2 use, and why is multicasting preferable to broadcasting?
10. Which transport protocol and port does RIP use?

---

# Chapter 4 — OSPF: Open Shortest Path First

## 4.1 Overview

**Open Shortest Path First (OSPF)** is another interior routing protocol. To handle routing efficiently and in a timely manner, OSPF **divides an autonomous system into areas**.

## 4.2 Areas

An **area** is a collection of networks, hosts, and routers all contained within an autonomous system. An autonomous system can be divided into many different areas, and all networks inside an area must be connected.

Routers inside an area **flood** the area with routing information. Each area has a special router called an **area border router**, which summarizes the information about the area and sends it to other areas.

Among the areas inside an autonomous system is a special area called the **backbone**. All of the areas inside an AS must be connected to the backbone. The routers inside the backbone are called **backbone routers** — note that a backbone router can also be an area border router at the same time.

If the connectivity between a backbone and an area is broken, a **virtual link** must be created by the administrator to restore it.

Each area has an **area identification**. The area identification of the backbone is **zero**.

![Areas in an autonomous system](images/fig-13-18-areas.png)

*Figure 4.1 — Areas in an autonomous system: area 1 and area 2 connect to area 0, the backbone, through area border routers; an AS boundary router connects the AS to other ASs.*

## 4.3 Metrics

OSPF allows the administrator to assign a cost, called the **metric**, to each route. The metric can be based on a **type of service**, such as:

- **Minimum delay**
- **Maximum throughput**

A router can have **multiple routing tables**, each based on a different type of service.

## 4.4 Link State Routing

OSPF uses **link state routing** to update the routing table in an area. Link state routing is a process by which each router shares its knowledge about its neighborhood with **every router in the area**. The method rests on three keys:

1. **Sharing knowledge about the neighborhood.** Each router sends the state of its neighborhood to every other router in the area.
2. **Sharing with every other router.** Each router sends the state of its neighborhood to every other router in the area by **flooding**.
3. **Sharing when there is a change.** Each router shares the state of its neighborhood only when there is a change.

The idea behind link state routing is that each router should have the **exact topology** of the internet at every moment. In other words, every router should have the whole picture of the internet. From this picture, a router can calculate the shortest path between itself and each network. But to do so, we first need a way to represent an internet as a graph — and for that we need to classify the connections between routers and networks.

## 4.5 Types of Links

In OSPF, a connection is called a **link**. Four types of links are defined: **point-to-point**, **transient**, **stub**, and **virtual**.

![Types of links](images/fig-13-19-types-of-links.png)

*Figure 4.2 — The four types of OSPF links.*

### Point-to-Point Link

A **point-to-point link** connects two routers without any other host or router in between — for example, a telephone line or a T-line. In the graphical representation, the routers are represented by nodes and the link is represented by a **bidirectional edge**. The metrics are usually the same at the two ends.

![Point-to-point link](images/fig-13-20-point-to-point-link.png)

*Figure 4.3 — A point-to-point link and its graphical representation.*

### Transient Link

A **transient link** is a network with several routers attached to it. Data can enter through any of the routers and leave through any router. Examples are all LANs and some WANs with two or more routers.

Representing such a network by connecting every router to every other router would be:

- **Not efficient** — each router would need to advertise the neighborhood of four other routers, for a total of 20 advertisements; and
- **Not realistic** — there is no single network (link) between each pair of routers; there should be only one network that serves as a crossroad between all five routers.

The solution is to let **one of the routers act as the network**. This router has a dual purpose: it is a true router and a **designated router**. The links between the routers and the designated router are represented as bidirectional edges.

![Transient link](images/fig-13-21-transient-link.png)

*Figure 4.4 — A transient link: (a) the physical network, (b) the unrealistic full-mesh representation, (c) the designated-router representation.*

### Stub Link

A **stub link** is a network that is connected to only one router. Data packets enter and leave through this single router. A stub network is a special case of a transient network. In the graphical representation, the router is a node and the designated router represents the network — but note that the link is only **one-directional**: from the router to the network.

![Stub link](images/fig-13-22-stub-link.png)

*Figure 4.5 — A stub link and its one-directional graphical representation.*

### Virtual Link

When the link between two routers is broken, the administrator may create a **virtual link** between them: a virtual path that uses a longer path and may go through several routers.

The next two figures show a complete example internet and its translation into the graphical model used by the Dijkstra calculation.

![Example of an internet](images/fig-13-23-example-internet.png)

*Figure 4.6 — An example internet.*

![Graphical representation of an internet](images/fig-13-24-graphical-representation.png)

*Figure 4.7 — The graphical representation of the example internet.*

## 4.6 Link State Advertisements

Each entity distributes a **Link State Advertisement (LSA)** to share information about its neighbors. An LSA announces the states of the entity's links. There are **five LSAs**, depending on the type of entity:

1. **Router link**
2. **Network link**
3. **Summary link to network**
4. **Summary link to AS boundary router**
5. **External link**

![Types of LSAs](images/fig-13-25-types-of-lsas.png)

*Figure 4.8 — The five types of link state advertisements.*

### Router Link

A **router link** defines the links of a true router. A true router uses this advertisement to announce information about all of its links and what is at the other side of the links (its neighbors).

![Router link](images/fig-13-26-router-link.png)

*Figure 4.9 — Router link advertisement.*

### Network Link

A **network link** defines the links of a network. A **designated router**, on behalf of the transient network, distributes this type of LSA packet. The packet announces the existence of all of the routers connected to the network.

![Network link](images/fig-13-27-network-link.png)

*Figure 4.10 — Network link advertisement.*

### Summary Link to Network

Router link and network link advertisements flood the area with information *inside* an area. But a router must also know about the networks *outside* its area. The **area border routers** provide this information.

An area border router is active in more than one area. It receives router link and network link advertisements, creates a routing table for each area, and provides one area's information to the other areas by means of the **summary link to network** advertisement.

For example, in the figure below, R1 is an area border router with two routing tables: one for area 1 and one for area 0. R1 floods area 1 with information about how to reach a network located in area 0. R2 plays the same role in the opposite direction.

![Summary link to network](images/fig-13-28-summary-link-to-network.png)

*Figure 4.11 — Summary link to network advertisement.*

### Summary Link to AS Boundary Router

The previous advertisement lets every router know the cost to reach all of the networks **inside** the AS. But how does a router reach a network **outside** the AS? A router must first know how to reach the **autonomous system boundary router**, and the **summary link to AS boundary router** provides this information. The area border routers flood their area with it.

![Summary link to AS boundary router](images/fig-13-29-summary-link-to-asbr.png)

*Figure 4.12 — Summary link to AS boundary router advertisement.*

### External Link

How does a router inside an AS know which networks are available outside the AS? The **AS boundary router** floods the autonomous system with the cost of each network outside the AS, using a routing table created by an **exterior routing protocol**. Notably, each advertisement announces **one single network**; if more than one network exists, separate announcements are made for each.

![External link](images/fig-13-30-external-link.png)

*Figure 4.13 — External link advertisement.*

> **Example 4.1** — In the figure below, which router(s) send out router link LSAs?
>
> **Solution.** All routers advertise router link LSAs:
>
> | Router | Links |
> |---|---|
> | R1 | two links: Net1 and Net2 |
> | R2 | one link: Net2 (in this AS) |
> | R3 | two links: Net2 and Net3 |

![Topology for Examples 4.1 and 4.2](images/fig-13-31-example-3-4.png)

*Figure 4.14 — Topology for Examples 4.1 and 4.2.*

> **Example 4.2** — In the same figure, which router(s) send out the network link LSAs?
>
> **Solution.** All three networks must advertise network links:
>
> - Advertisement for **Net1** is done by **R1**, because it is the only router and therefore the designated router.
> - Advertisement for **Net2** can be done by either **R1, R2, or R3**, depending on which one is chosen as the designated router.
> - Advertisement for **Net3** is done by **R3**, because it is the only router and therefore the designated router.

## 4.7 The Link State Database and the Dijkstra Algorithm

Every router in an area receives the router link and network link LSAs from every other router and forms a **link state database**: a tabular representation of the topology of the internet inside an area. Notably, **every router in the same area has the same link state database**.

Each router then applies the **Dijkstra algorithm** to its link state database. The Dijkstra algorithm calculates the shortest path between two points. The algorithm builds the shortest path tree step by step: starting from itself, the router repeatedly makes the closest node permanent and adds that node's neighbors to the tentative list, until every node is on the tree.

![Shortest path calculation, part 1](images/fig-13-32-shortest-path-1.png)

*Figure 4.15 — Shortest path calculation, part 1: start with A; make A permanent and add its neighbors; make N1 permanent; make C permanent.*

![Shortest path calculation, part 2](images/fig-13-32-shortest-path-2.png)

*Figure 4.16 — Shortest path calculation, part 2.*

![Shortest path calculation, part 3](images/fig-13-32-shortest-path-3.png)

*Figure 4.17 — Shortest path calculation, part 3: the finished shortest path tree.*

## 4.8 The OSPF Routing Table

Each router uses the shortest path tree method to construct its routing table. The routing table in OSPF includes the cost of reaching each network **in the area**. To find the cost of reaching networks **outside** the area, the routers use the:

- Summary link to network advertisements,
- Summary link to (AS) boundary router advertisements, and
- External link advertisements.

## 4.9 OSPF Packets

OSPF uses **five different packets**:

1. **Hello packet**
2. **Database description packet**
3. **Link state request packet**
4. **Link state update packet** — which carries the five kinds of LSA (router link, network link, summary link to network, summary link to AS boundary router, and external link)
5. **Link state acknowledgment packet**

![Types of OSPF packets](images/fig-13-33-ospf-packets.png)

*Figure 4.18 — The five types of OSPF packets.*

### The Common Header

All OSPF packets share the same header:

| Field | Size | Description |
|---|---|---|
| **Version** | 8 bits | The version of the OSPF protocol; currently it is **2**. |
| **Type** | 8 bits | The type of the packet. |
| **Message length** | 16 bits | The length of the total message including the header. |
| **Source router IP address** | 32 bits | The IP address of the router that sends the packet. |
| **Area identification** | 32 bits | The area within which the routing takes place. |
| **Checksum** | 16 bits | Error detection on the entire packet, excluding the authentication type and authentication data fields. |
| **Authentication type** | 16 bits | Defines the authentication method used in this area: **0 = none, 1 = password**. |
| **Authentication** | 64 bits | The actual value of the authentication data: filled with 0s if the type is 0; an eight-character password if the type is 1. |

![OSPF packet header](images/fig-13-34-ospf-header.png)

*Figure 4.19 — The common OSPF packet header.*

### Hello Packet

OSPF uses the **hello message** to:

- Create neighborhood relationships, and
- Test the reachability of neighbors.

This is the first step in link state routing: before a router can flood the area with information about its neighbors, it must first greet its neighbors.

![Hello packet](images/fig-13-35-hello-packet.png)

*Figure 4.20 — The hello packet.*

The hello packet fields are:

- **Network mask (32 bits)** — defines the network mask of the network over which the hello message is sent.
- **Hello interval (16 bits)** — defines the number of seconds between hello messages.
- **E flag (1 bit)** — if it is set, the area is a **stub area**.
- **F flag (1 bit)** — if it is set, the router supports **multiple metrics**.
- **Priority** — the priority of the router, used for the selection of the designated router. The router with the highest priority is chosen as the designated router; the router with the second highest priority is chosen as the backup designated router. If the priority is 0, the router never wants to be a designated or backup designated router.
- **Dead interval (32 bits)** — the number of seconds before a router assumes that a neighbor is dead.
- **Designated router IP address (32 bits)**.
- **Backup designated router IP address (32 bits)**.
- **Neighbor IP address (a repeated 32-bit field)** — a current list of all the neighbors from which the sending router has received hello messages.

### Database Description Packet

When a router is connected to the system for the first time — or after a failure — it needs the complete link state database **immediately**. It sends hello packets to greet its neighbors, and if this is the first time the neighbors hear from the router, they send a **database description packet**.

The database description message does not contain complete database information. It only gives an **outline** — the title of each line in the database. The new router examines the outline, finds out which lines it does not have, and sends one or more **link state request packets** to get full information about those particular links. The content of the database may be divided into several messages.

When two routers want to exchange database description packets, one of them acts as the **master** and the other as the **slave**.

![Database description packet](images/fig-13-36-database-description.png)

*Figure 4.21 — The database description packet.*

The database description message fields are:

- **E flag (1 bit)** — set to 1 if the advertising router is an autonomous system boundary router.
- **B flag (1 bit)** — set to 1 if the advertising router is an area border router.
- **I flag (1 bit)** — the initialization flag; set to 1 if the message is the first message.
- **M flag (1 bit)** — the more flag; set to 1 if this is not the last message.
- **M/S flag (1 bit)** — the master/slave flag; indicates the origin of the packet: master = 1, slave = 0.
- **Message sequence number (32 bits)** — contains the sequence number of the message.
- **LSA header (20 bytes)** — the header used in each LSA (discussed with the link state update message). It gives only the outline of each link, and is repeated for each link in the link state database.

### Link State Request Packet

The **link state request packet** is sent by a router that needs information about a specific route or routes. It is answered with a link state update packet. It is used by a newly connected router to request more information after receiving the database description packet.

![Link state request packet](images/fig-13-37-link-state-request.png)

*Figure 4.22 — The link state request packet.*

### Link State Update Packet

The **link state update packet** is used by a router to advertise the state of its links. Each update packet may contain several different LSAs. Its format is:

- **Number of link state advertisements (32 bits)**, followed by
- **Link state advertisements** — there are five different LSAs, as discussed before; all have the same header format but different bodies.

![Link state update packet](images/fig-13-38-link-state-update.png)

*Figure 4.23 — The link state update packet.*

### The LSA Header

All five LSAs share a common 20-byte header with the following fields:

- **Link state age** — the number of seconds elapsed since this message was first generated. Recall that an LSA goes from router to router (flooding). When a router creates the message, the age is 0; when each successive router forwards the message, it estimates the transit time and adds it to the age field.
- **E flag** — if 1, the area is a stub area; that is, an area that is connected to the backbone area by only one path.
- **T flag** — if 1, the router can handle multiple types of service.
- **Link state type** — 1: router link; 2: network link; 3: summary link to network; 4: summary link to AS boundary router; 5: external link.
- **Link state ID** — depends on the type of link:
  - Router link → IP address of the router
  - Network link → IP address of the designated router
  - Summary link to network → address of the network
  - Summary link to AS boundary router → IP address of the AS boundary router
  - External link → address of the external network
- **Advertising router** — the IP address of the router advertising this message.
- **Link state sequence number** — the sequence number assigned to each link state update message.
- **Link state checksum** — a special checksum algorithm: **Fletcher's checksum**.
- **Length** — the total packet length.

![LSA header](images/fig-13-39-lsa-header.png)

*Figure 4.24 — The common LSA header.*

## 4.10 The LSA Formats

### Router Link LSA

The router link LSA advertises all of the links of a router. Its fields are:

- **Link ID** — depends on the type of link (see Table 4.1).
- **Link data** — gives additional information about the link; also depends on the type of link (see Table 4.1).
- **Link type** — four different types of links are defined based on the type of network (see Table 4.1).
- **Number of types of service (TOS)** — the number of types of service announced for each link.
- **Metric for TOS 0** — defines the metric for the default type of service (TOS 0).
- **TOS** — defines the type of service.
- **Metric** — defines the metric for the corresponding TOS.

![Router link LSA](images/fig-13-40-router-link-lsa.png)

*Figure 4.25 — The router link LSA format.*

**Table 4.1 — Link types, link identifications, and link data**

| Link type | Link identification | Link data |
|---|---|---|
| Type 1: point-to-point connection to another router | Address of neighbor router | Interface number |
| Type 2: connection to any-to-any network | Address of designated router | Router address |
| Type 3: connection to stub network | Network address | Network mask |
| Type 4: virtual link | Address of neighbor router | Router address |

> **Example 4.3** — Give the router link LSA sent by router 10.24.7.9 in the figure below.

![Topology for Example 4.3](images/fig-13-41-example-5.png)

*Figure 4.26 — Topology for Example 4.3.*

> **Solution.** This router has three links: two of type 1 (point-to-point) and one of type 3 (stub network). The resulting router link LSA is shown below.

![Solution to Example 4.3](images/fig-13-42-solution-example-5.png)

*Figure 4.27 — The router link LSA sent by router 10.24.7.9.*

### Network Link LSA

The network link LSA announces the links connected to a network. Its fields are:

- **Network mask** — defines the network mask.
- **Attached router** — defines the IP addresses of all attached routers (repeated for each attached router).

![Network link LSA](images/fig-13-43-network-link-lsa.png)

*Figure 4.28 — The network link advertisement format.*

### Summary Link to Network LSA

The summary link to network LSA is used by the area (border) router to announce the existence of other networks outside the area. Each advertisement announces **only one network**; if there is more than one network, a separate advertisement must be issued for each. Its fields are:

- **Network mask**
- **TOS** — type of service.
- **Metric** — the metric for the type of service defined in the TOS field.

![Summary link to network LSA](images/fig-13-46-summary-link-network-lsa.png)

*Figure 4.29 — The summary link to network LSA format.*

### Summary Link to AS Boundary Router LSA

The summary link to AS boundary router LSA announces the route to an AS boundary router. It defines the network to which the AS boundary router is attached. Its format is the **same as** the summary link to network LSA.

![Summary link to AS boundary router LSA](images/fig-13-47-summary-link-asbr-lsa.png)

*Figure 4.30 — The summary link to AS boundary router LSA format.*

### External Link LSA

The external link LSA announces all the networks outside the AS. Its format is similar to the summary link to AS boundary router LSA, but with two additional fields:

- **Forwarding address** — defines a forwarding router that can provide a better route to the destination.
- **External route tag** — used by other protocols, but not by OSPF.

![External link LSA](images/fig-13-48-external-link-lsa.png)

*Figure 4.31 — The external link LSA format.*

### Link State Acknowledgment Packet

OSPF forces every router to acknowledge the receipt of every link state update packet. This makes routing more reliable. The acknowledgment packet consists of the **common header** followed by the **link state header**.

![Link state acknowledgment packet](images/fig-13-49-link-state-ack.png)

*Figure 4.32 — The link state acknowledgment packet.*

## 4.11 Encapsulation

OSPF packets are encapsulated in **IP datagrams**. OSPF contains its own acknowledgment mechanism for flow and error control, so it does not need a transport layer protocol to provide these services.

> **Note:** OSPF packets are encapsulated in IP datagrams.

### Chapter 4 Summary

- OSPF is an interior routing protocol that divides an AS into areas; all areas connect to the backbone (area 0), and a broken connection is repaired with a virtual link.
- The OSPF metric is an administrator-assigned cost based on type of service (minimum delay, maximum throughput); a router may keep multiple routing tables.
- In link state routing, each router shares the state of its neighborhood with every other router in the area (flooding), but only when there is a change.
- Four link types exist: point-to-point, transient, stub, and virtual. Transient networks are represented through a designated router; stub links are one-directional.
- Five LSAs distribute information: router link, network link, summary link to network, summary link to AS boundary router, and external link.
- All routers in an area share the same link state database; each runs the Dijkstra algorithm on it to build a shortest path tree and a routing table.
- Five packet types exist: hello, database description, link state request, link state update, and link state acknowledgment; all share a common header.
- The hello packet creates neighborhood relationships and tests reachability; the database description packet gives an outline of the database; the link state request asks for specific routes; the update carries LSAs; the acknowledgment makes flooding reliable.
- OSPF packets are encapsulated directly in IP datagrams.

### Review Questions

1. What is an area, and why does OSPF divide an AS into areas?
2. What is the backbone? What is its area identification? What happens if the connection between the backbone and an area is broken?
3. State the three keys of link state routing and contrast them with those of distance vector routing.
4. Name the four types of OSPF links and give an example of each.
5. Why is a designated router used on a transient network?
6. Which LSA does a designated router distribute? Which entity distributes the external link LSA, and where does its routing information come from?
7. What is the link state database? What do all routers in the same area have in common?
8. List the five OSPF packet types and give a one-line description of each.
9. What is the purpose of the priority field in the hello packet?
10. Why does OSPF not need a transport layer protocol?

---

# Chapter 5 — BGP: Border Gateway Protocol

## 5.1 Overview

The **Border Gateway Protocol (BGP)** is an **inter-autonomous system routing protocol**. It is based on the **path vector routing** method.

## 5.2 Why Neither Distance Vector nor Link State?

Why are distance vector routing and link state routing not good candidates for inter-autonomous system routing?

**Distance vector routing** is unsuitable because:

- There are occasions in which the route with the smallest hop count is not the preferred route. For example, we may not want a packet to pass through an AS that is not secure, even if it is the shortest path.
- It is unstable, as discussed in Chapter 3.

**Link state routing** is unsuitable because:

- An internet is usually too big for this routing method. If it were used, each router would have to maintain a huge link state database, and it would take a long time for each router to calculate its routing table using the Dijkstra algorithm.

## 5.3 Path Vector Routing

In path vector routing, each entry in the routing table contains:

- The **destination network**,
- The **next router**, and
- The **path** to reach the destination — usually defined as an ordered list of autonomous systems.

For example, a path vector routing table might look like this:

| Network | Next router | Path |
|---|---|---|
| N01 | R01 | AS14, AS23, AS67 |
| N02 | R05 | AS22, AS67, AS05, AS89 |
| N03 | R06 | AS67, AS89, AS09, AS34 |
| N04 | R12 | AS62, AS02, AS09 |

### Path Vector Messages

The autonomous boundary routers advertise the reachability of networks in their own AS to neighbor autonomous boundary routers. Each router that receives a path vector message:

1. Verifies that the advertised path is in agreement with its **policy**.
2. If yes, updates its routing table and modifies the message before sending it to the next router: it **adds its AS number to the path** and **replaces the next router entry with its own identification**.

For example, in the figure below, router R1 sends a path vector message advertising the reachability of N1. Router R2 receives the message, updates its routing table, and sends the message on to R3 — adding its own AS to the path and inserting itself as the next router.

![Path vector packets](images/fig-13-50-path-vector-packets.png)

*Figure 5.1 — Path vector packets traveling between autonomous boundary routers.*

## 5.4 Loop Prevention and Policy Routing

### Loop Prevention

Path vector routing can solve the instability of distance vector routing — the creation of loops. When a router receives a message, it checks to see whether **its own AS is in the path list**. If it is, looping is involved and the message is **ignored**.

### Policy Routing

Policy routing can be easily implemented through path vector routing. Once a router receives a message, it can check the path. If one of the ASs listed in the path is against its policy, it can **ignore that path and that destination**:

- It does not update its routing table with this path, and
- It does not send this message to its neighbors.

Thus, path vector routing is **not** based on the smallest hop count or the minimum metric; it is based on the **policy** imposed on the router by the administrator.

## 5.5 Path Attributes

In the previous example, the path was presented as a list of ASs. In reality, the path is presented as a list of **attributes**. The list of attributes helps the receiving router make a better decision when applying its policy.

Attributes are divided into two categories: **well-known** and **optional**.

### Well-Known Attributes

A well-known attribute is one that every BGP router should recognize.

- **Mandatory** — must appear in the description of a route. Examples:
  - **ORIGIN** — the source of the routing information (RIP or OSPF).
  - **AS_PATH** — the list of autonomous systems through which the destination can be reached.
  - **NEXT_HOP** — the next router to which the data packet should be sent.
- **Discretionary** — must be recognized by each router, but is not required to be included in every update message.

### Optional Attributes

An optional attribute is one that need not be recognized by every router.

- **Transitive** — must be passed to the next router by a router that has not implemented this attribute.
- **Nontransitive** — should be discarded if the receiving router has not implemented it.

## 5.6 BGP Messages

BGP uses **four different types of messages**: **open**, **update**, **keepalive**, and **notification**.

![Types of BGP messages](images/fig-13-51-bgp-messages.png)

*Figure 5.2 — The four types of BGP messages.*

### The Common Header

All BGP packets share the same common header:

| Field | Size | Description |
|---|---|---|
| **Marker** | 16 bytes | Reserved for authentication. |
| **Length** | 2 bytes | Defines the length of the total message, including the header. |
| **Type** | 1 byte | Defines the type of the packet. |

![BGP packet header](images/fig-13-52-bgp-header.png)

*Figure 5.3 — The BGP packet header.*

### Open Message

The **open message** is used to create a neighborhood relationship. A router running BGP opens a TCP connection with a neighbor and sends an open message. If the neighbor accepts, it responds with a **keepalive message** — the relationship has then been established between the two routers.

![Open message](images/fig-13-53-open-message.png)

*Figure 5.4 — The open message.*

The open message fields are:

- **Version (1 byte)** — defines the version of BGP; the current version is **4**.
- **My autonomous system (2 bytes)** — defines the autonomous system number.
- **Hold time (2 bytes)** — defines the maximum number of seconds that can elapse before one of the parties receives a keepalive or update message from the other. If a router does not receive one of these messages during the hold period, it considers the other party **dead**.
- **BGP identifier (4 bytes)** — defines the router that sends the open message.
- **Option parameter length (1 byte)** — defines the length of the total option parameters (the open message may also contain some option parameters).
- **Option parameters** — the only option parameter defined so far is **authentication**.

### Update Message

The **update message** is used by a router to:

- **Withdraw** destinations that have been advertised previously, and
- **Announce** a route to a new destination.

Note that a router can withdraw **several** destinations in a single update message, but it can only advertise **one** new destination in a single update message.

The update message fields are:

- **Unfeasible routes length (2 bytes)** — defines the length of the next field.
- **Withdrawn routes** — lists all routes that should be deleted from the previously advertised list.
- **Path attributes length (2 bytes)** — defines the length of the next field.
- **Path attributes** — defines the attributes of the path (route) to the network whose reachability is being announced in this message.
- **Network layer reachability information (NLRI)** — defines the network that is actually advertised by this message. It has two fields: a **length** field, which defines the number of bits in the prefix, and an **IP address prefix** field. Because the network is identified by a prefix, **BGP version 4 supports classless addressing and CIDR**.

![Update message](images/fig-13-54-update-message.png)

*Figure 5.5 — The update message.*

### Keepalive Message

The BGP routers exchange **keepalive messages** regularly to tell each other that they are alive. The keepalive message consists of only the common header.

![Keepalive message](images/fig-13-55-keepalive-message.png)

*Figure 5.6 — The keepalive message.*

### Notification Message

The **notification message** is sent by a router whenever an error condition is detected, or when a router wants to close the connection. Its fields are:

- **Error code (1 byte)** — defines the category of the error:
  - Message header error
  - Open message error
  - Update message error
  - Hold timer expired
  - Finite state machine error
  - Cease
- **Error subcode (1 byte)** — further defines the type of error in each category.
- **Error data** — used to give more diagnostic information about the error.

![Notification message](images/fig-13-56-notification-message.png)

*Figure 5.7 — The notification message.*

## 5.7 Encapsulation

BGP messages are encapsulated in **TCP segments** using the well-known port **179**. There is no need for error control and flow control, because TCP provides these services. When a TCP connection is opened, the exchange of update, keepalive, and notification messages is continued until a notification message of type **cease** is sent.

> **Note:** BGP uses the services of TCP on port 179.

### Chapter 5 Summary

- BGP is an inter-autonomous system routing protocol based on path vector routing.
- Distance vector routing is unsuitable between ASs (the shortest route is not always preferred; instability), and link state routing is unsuitable (the internet is too large for a complete database and fast Dijkstra calculation).
- A path vector routing table entry contains the destination network, the next router, and the path (an ordered list of ASs).
- Loop prevention: a router ignores a message whose path already contains its own AS.
- Policy routing: a router ignores any path that contains an AS contrary to its policy — path vector routing is based on administrator policy, not on minimum metrics.
- Path attributes are well-known (mandatory: ORIGIN, AS_PATH, NEXT_HOP; or discretionary) or optional (transitive or nontransitive).
- Four message types exist: open (creates the neighborhood relationship), update (withdraws several routes or announces one new route, carries NLRI with prefix → CIDR support), keepalive (header only), and notification (error reporting and connection closing).
- BGP messages are encapsulated in TCP segments on port 179.

### Review Questions

1. Why is distance vector routing a poor choice for inter-AS routing?
2. Why is link state routing a poor choice for inter-AS routing?
3. What three pieces of information does a path vector routing table entry contain?
4. How does path vector routing prevent loops?
5. How is policy routing implemented in BGP?
6. Explain the difference between well-known mandatory, well-known discretionary, optional transitive, and optional nontransitive attributes.
7. Name the four BGP message types and the purpose of each.
8. How many destinations can be withdrawn in a single update message? How many new destinations can be announced?
9. Which field of the update message allows BGP4 to support CIDR, and why?
10. Which transport protocol and port does BGP use, and what are the consequences for error and flow control?

---

# Chapter 6 — Comparing RIP, OSPF, and BGP

The three protocols in this book answer the same question — *which path should a packet take?* — in three very different ways. The table below places them side by side.

| Aspect | RIP | OSPF | BGP |
|---|---|---|---|
| **Role** | Interior routing protocol | Interior routing protocol | Exterior (inter-AS) routing protocol |
| **Routing method** | Distance vector | Link state | Path vector |
| **Algorithm** | Bellman–Ford | Dijkstra (shortest path tree) | Policy-based path selection |
| **Metric** | Hop count (every network costs 1) | Administrator-assigned cost based on type of service (minimum delay, maximum throughput) | Policy set by the administrator |
| **Scope of information** | Shares knowledge of the whole AS with neighbors only | Shares knowledge of the neighborhood with every router in the area (flooding) | AS boundary routers advertise network reachability to neighbor AS boundary routers |
| **When information is sent** | Periodically every 30 s (25–35 s randomized) and on triggered updates | Only when there is a change | On change, via update messages over an established TCP connection |
| **Scalability mechanism** | Hop count limited to 15 (16 = unreachable) | AS divided into areas connected to a backbone (area 0) | Path vector with AS lists; policy filtering |
| **Loop/instability control** | Triggered updates, split horizons, poison reverse | Every router in an area shares the same link state database and a complete topology view | A router ignores any path already containing its own AS |
| **Classless addressing / CIDR** | Supported in RIP version 2 (subnet mask field) | Network masks carried in LSAs | Supported in BGP4 (NLRI prefix) |
| **Messages / packets** | Request, response (solicited and unsolicited) | Hello, database description, link state request, link state update, link state acknowledgment | Open, update, keepalive, notification |
| **Reliability mechanism** | None of its own (runs over UDP) | Its own acknowledgment of every link state update | Provided by TCP |
| **Encapsulation** | UDP user datagrams, port 520 | Directly in IP datagrams | TCP segments, port 179 |

**How to choose.** Inside a small autonomous system, RIP is simple and adequate, provided the diameter stays within 15 hops and slow convergence is acceptable. For larger or performance-sensitive autonomous systems, OSPF's area hierarchy, type-of-service metrics, and change-driven flooding converge far faster and scale far better. Between autonomous systems — where the internet is too large for link state methods and where "shortest" is not always "best" — BGP's path vector routing with administrator-defined policy is the standard choice.

---

# Appendix A — Quick-Reference Tables

## A.1 RIP Timers

| Timer | Value | Purpose |
|---|---|---|
| Periodic | 25–35 s (randomized; protocol specifies 30 s) | Controls advertising of regular update messages; randomization prevents simultaneous updates. |
| Expiration | 180 s | Governs route validity; reset on each new update. On expiry the hop count is set to 16 (unreachable). |
| Garbage collection | 120 s | Keeps an invalid route advertised with metric 16 so neighbors learn of the invalidity before the route is purged. |

## A.2 RIP Message Fields

| Field | Size | Meaning |
|---|---|---|
| Command | 8 bits | Request (1) or response (2) |
| Version | 8 bits | RIP version |
| Family | 16 bits | Protocol family; 2 for TCP/IP; FFFF (hex) marks an authentication entry in RIPv2 |
| Address | 14 bytes | Destination network address (IP uses 4 bytes, rest are 0s) |
| Distance | 32 bits | Hop count to the destination network |
| *(RIPv2 only)* Routing tag, Subnet mask, Next-hop address | — | AS number and exterior-protocol information; CIDR support; explicit next hop |

## A.3 OSPF Packet Types

| Packet | Purpose |
|---|---|
| Hello | Create neighborhood relationships; test reachability of neighbors |
| Database description | Give an outline (titles) of the link state database to a new router |
| Link state request | Ask for full information about specific routes |
| Link state update | Advertise the state of links; carries one or more LSAs |
| Link state acknowledgment | Acknowledge receipt of every link state update (reliability) |

## A.4 OSPF LSA Types

| Type | LSA | Originated by | Link state ID |
|---|---|---|---|
| 1 | Router link | Every true router | IP address of the router |
| 2 | Network link | Designated router of a transient network | IP address of the designated router |
| 3 | Summary link to network | Area border router | Address of the network |
| 4 | Summary link to AS boundary router | Area border router | IP address of the AS boundary router |
| 5 | External link | AS boundary router | Address of the external network |

## A.5 OSPF Link Types (Router Link LSA)

| Link type | Link identification | Link data |
|---|---|---|
| 1: point-to-point | Address of neighbor router | Interface number |
| 2: any-to-any (transient) network | Address of designated router | Router address |
| 3: stub network | Network address | Network mask |
| 4: virtual link | Address of neighbor router | Router address |

## A.6 BGP Message Types

| Message | Purpose |
|---|---|
| Open | Create a neighborhood relationship (after TCP connection; answered with keepalive) |
| Update | Withdraw previously advertised routes and/or announce one new route (NLRI prefix → CIDR) |
| Keepalive | Tell the neighbor the router is alive; header only |
| Notification | Report an error or close the connection (error codes: message header, open, update, hold timer expired, finite state machine, cease) |

## A.7 BGP Path Attributes

| Category | Subcategory | Rule | Examples |
|---|---|---|---|
| Well-known | Mandatory | Must appear in the description of a route | ORIGIN, AS_PATH, NEXT_HOP |
| Well-known | Discretionary | Must be recognized, but not required in every update | — |
| Optional | Transitive | Passed on even if not implemented | — |
| Optional | Nontransitive | Discarded if not implemented | — |

## A.8 Well-Known Ports and Encapsulation

| Protocol | Encapsulation | Port / Protocol |
|---|---|---|
| RIP | UDP user datagram | UDP port 520 |
| OSPF | IP datagram | Directly over IP (own acknowledgment mechanism) |
| BGP | TCP segment | TCP port 179 |

---

# Appendix B — Glossary

**Area** — A collection of networks, hosts, and routers within an OSPF autonomous system. All networks inside an area must be connected.

**Area border router** — A router that is active in more than one area; it summarizes one area's information and sends it to other areas.

**AS boundary router** — The router that connects an autonomous system to other autonomous systems; it floods the AS with the cost of reaching external networks.

**Autonomous system (AS)** — A group of networks and routers under the authority of a single administration.

**Backbone** — The special OSPF area (identification zero) to which all other areas must be connected.

**Bellman–Ford algorithm** — The algorithm used by RIP (distance vector routing) to calculate routing tables.

**Counting to infinity** — The instability of distance vector routing in which routers feed each other ever-increasing metrics for an unreachable network.

**Designated router** — A router on a transient network that acts as the network in the graphical representation and distributes the network link LSA on the network's behalf.

**Dijkstra algorithm** — The shortest-path algorithm each OSPF router applies to its link state database.

**Distance vector routing** — A routing method in which each router periodically shares its knowledge of the entire AS with its neighbors only.

**Exterior routing** — Routing between autonomous systems (e.g., BGP).

**Flooding** — Sending information out through every link so that it reaches every router (used by link state routing).

**Garbage collection timer** — The 120-second RIP timer that delays purging an invalid route so neighbors learn of its invalidity.

**Hop count** — The RIP metric: the number of networks traversed; limited to 15, with 16 meaning unreachable.

**Interior routing** — Routing inside an autonomous system (e.g., RIP, OSPF).

**Link state advertisement (LSA)** — An OSPF announcement of the states of an entity's links; five types exist.

**Link state database** — The tabular representation of an area's topology that every OSPF router in the area builds from received LSAs; identical on all routers in the area.

**Link state routing** — A routing method in which each router shares the state of its neighborhood with every other router in the area, by flooding, only when there is a change.

**Metric** — A cost assigned for passing through a network; routers prefer the route with the smallest metric.

**Path vector routing** — The routing method used by BGP, in which each routing entry carries the destination, the next router, and the ordered list of ASs forming the path.

**Poison reverse** — A split-horizon variation in which a route learned on an interface is advertised back out of that interface with metric 16.

**Policy routing** — Choosing routes according to administrator-defined policy rather than minimum metric; the basis of BGP.

**Split horizons** — The rule that routing information learned on an interface must not be advertised back out of that interface.

**Stub area** — An area connected to the backbone by only one path (signaled by the E flag).

**Stub link** — A network connected to only one router; represented by a one-directional edge from router to network.

**Transient link** — A network with several routers attached, through which data can enter and leave via any router; represented using a designated router.

**Triggered update** — Sending the routing table immediately when a change occurs, instead of waiting for the periodic interval.

**Virtual link** — An administrator-created path between two routers whose direct link is broken (may traverse several routers); also used to reconnect an area to a broken backbone.

---

# Appendix C — Answers to Review Questions

## Chapter 1

1. A metric is a cost assigned for passing through a network.
2. RIP treats all networks as equal (each costs one hop count); OSPF lets the administrator assign a cost based on the type of service, such as minimum delay or maximum throughput.
3. Policy, set by the administrator.
4. Because the network changes constantly; dynamic tables, maintained by routing protocols, update themselves automatically.

## Chapter 2

1. A group of networks and routers under the authority of a single administration.
2. Because an internet can be so large that one routing protocol cannot handle updating the routing tables of all routers.
3. RIP and OSPF are interior; BGP is exterior.
4. The boundary routers of the AS.

## Chapter 3

1. Share knowledge about the entire AS; share only with neighbors; share at regular intervals.
2. The entry in the table is replaced with the advertised one (refreshed).
3. Only the directly attached networks, with hop count 1, taken from its configuration file.
4. Periodic timer — 25–35 s — controls regular update advertising; expiration timer — 180 s — governs route validity (expired route gets metric 16); garbage collection timer — 120 s — delays purging an invalid route while it is advertised with metric 16.
5. Expiration timers: 30 − 8 = 22; garbage collection timers: 8 (plus 1 periodic timer).
6. To prevent packets from wandering forever and to bound the damage of counting to infinity; 16 means infinity — the network is unreachable.
7. Split horizon simply does not send the information back out of the interface it came from; poison reverse does send it back, but with the metric set to 16.
8. Routing tag (carries the AS number; allows information from an exterior routing protocol), subnet mask (supports classless addressing and CIDR), next-hop address (shows the next hop).
9. 224.0.0.9; multicasting delivers RIP messages only to RIP routers instead of to every router and host.
10. UDP, well-known port 520.

## Chapter 4

1. An area is a collection of networks, hosts, and routers within an AS; dividing the AS into areas lets OSPF handle routing efficiently and in a timely manner.
2. The backbone is the special area to which all areas must connect; its area identification is zero; the administrator must create a virtual link.
3. Share knowledge about the neighborhood (distance vector shares about the whole AS); share with every other router by flooding (distance vector shares only with neighbors); share only when there is a change (distance vector shares periodically).
4. Point-to-point (telephone line, T-line), transient (LANs and some WANs), stub (a network with only one router), virtual (a longer administrator-created path replacing a broken link).
5. Because representing the network as a full mesh between its routers is inefficient (many advertisements) and unrealistic (there is no single link between each pair); the designated router acts as the network.
6. The network link LSA; the AS boundary router distributes the external link LSA, using a routing table created by an exterior routing protocol.
7. A tabular representation of the topology of the internet inside an area; every router in the same area has the same link state database.
8. Hello (create neighborhood relationships and test reachability), database description (outline of the database), link state request (ask for specific routes), link state update (carry LSAs), link state acknowledgment (confirm receipt of updates).
9. It is used to elect the designated router (highest priority) and backup designated router (second highest); priority 0 means the router never wants either role.
10. Because OSPF contains its own acknowledgment mechanism for flow and error control, and its packets are encapsulated directly in IP datagrams.

## Chapter 5

1. The route with the smallest hop count is not always preferred (e.g., an insecure AS should be avoided), and distance vector routing is unstable.
2. An internet is too big: each router would need a huge link state database, and the Dijkstra calculation would take too long.
3. The destination network, the next router, and the path (an ordered list of ASs).
4. A router checks whether its own AS already appears in the path list of a received message; if so, the message is ignored.
5. On receiving a message, the router checks the path; if any AS in the path violates its policy, it ignores that path and destination, does not update its table, and does not forward the message.
6. Well-known mandatory attributes must be recognized by every BGP router and must appear in every route description (ORIGIN, AS_PATH, NEXT_HOP); well-known discretionary attributes must be recognized but need not appear in every update; optional transitive attributes need not be recognized but must be passed on; optional nontransitive attributes are discarded if not implemented.
7. Open — create a neighborhood relationship; update — withdraw routes and/or announce one new route; keepalive — show the router is alive; notification — report an error or close the connection.
8. Several destinations can be withdrawn; only one new destination can be announced.
9. The network layer reachability information (NLRI) field, because it identifies the advertised network as an IP address prefix with an explicit prefix length.
10. TCP, port 179; error control and flow control are provided by TCP, and the exchange of messages continues until a notification message of type cease is sent.

---

*End of book. Adapted from the CSA510 lecture slides "Routing Protocols (RIP, OSPF, and BGP)".*
